import axios from "axios";
import { useEffect, useState } from "react";

const Suggestions = () => {
  const [profile, setProfile] = useState(null);
  const [suggestions, setsuggestions] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/profile")
      .then((data) => data.json())
      .then((data) => setProfile(data))
      .catch((err) => console.log(err));

    fetch("http://localhost:3000/suggestions")
      .then((data) => data.json())
      .then((data) => setsuggestions(data))
      .catch((err) => console.log(err));
  }, []);

  const handleFollow=async(id,username)=>{
    axios.post('http://localhost:3000/followers',{"id":id,"username":username})
    .then(alert('followed'))
    .catch(err=>console.log(err))
  }
  return (
    <div className="suggestions m-4">
      {profile ? (
        <div className="d-flex">
          <img
            className="dp rounded-circle"
            src={profile.profilePic}
            alt="profilePic"
          />
          <h5>{profile.username}</h5>
          <a className="ms-auto text-primary">Switch</a>
        </div>
      ) : (
        <p>Loading</p>
      )}
      <div className="d-flex mt-2">
        <p>Suggested for You</p>
        <b className="ms-auto">See All</b>
      </div>

      {suggestions.length > 0 ? (
        <div>
          {suggestions.map((suggestion) => (
            <div key={suggestion.id}>
              <div className="d-flex unfollow">
                <img
                  className="dp rounded-circle "
                  src={suggestion.profilePic}
                  alt="profilePic"
                />
                <h5>{suggestion.username}</h5>
                <button onClick={()=>{handleFollow(suggestion.id,suggestion.username)}} className="cursor-pointer btn btn-primary ms-auto mb-2">Follow</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div>Loading</div>
      )}
    </div>
  );
};

export default Suggestions;

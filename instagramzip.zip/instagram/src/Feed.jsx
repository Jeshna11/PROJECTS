
import Posts from './Posts'
import Stories from './Stories'

const Feed = () => {
  return (
    <div>
      <div><Stories /></div>
      <div><Posts /></div>
    </div>
  )
}

export default Feed

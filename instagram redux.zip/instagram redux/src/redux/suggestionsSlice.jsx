import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
export const fetchSuggestions = createAsyncThunk('suggestions/fetchSuggestions', async () => {
  const res = await fetch('http://localhost:3000/suggestions')
  return await res.json()
})
const suggestionsSlice = createSlice({
  name: 'suggestions',
  initialState: [],
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchSuggestions.fulfilled, (_, action) => action.payload)
  }
})
export default suggestionsSlice.reducer
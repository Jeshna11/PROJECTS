import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

export const fetchProfile = createAsyncThunk('profile/fetchProfile', async () => {
  const res = await axios.get('http://localhost:3000/profile')
  return res.data
})

export const updateProfile = createAsyncThunk('profile/updateProfile', async (profile) => {
  await axios.put('http://localhost:3000/profile', profile)
  return profile
})

const profileSlice = createSlice({
  name: 'profile',
  initialState: null,
  reducers: {
    setProfileField: (state, action) => {
      const { field, value } = action.payload
      state[field] = value
    }
  },
  extraReducers: (builder) => {
    builder.addCase(fetchProfile.fulfilled, (_, action) => action.payload)
    builder.addCase(updateProfile.fulfilled, (_, action) => action.payload)
  }
})

export const { setProfileField } = profileSlice.actions
export default profileSlice.reducer

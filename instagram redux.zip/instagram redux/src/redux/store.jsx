import { configureStore } from '@reduxjs/toolkit'
import postsReducer from './postsSlice'
import profileReducer from './profileSlice'
import suggestionsReducer from './suggestionsSlice'
import storiesReducer from './storiesSlice'

export const store = configureStore({
  reducer: {
    posts: postsReducer,
    profile: profileReducer,
    suggestions: suggestionsReducer,
    stories: storiesReducer
  }
})

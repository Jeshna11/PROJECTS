import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'

export const fetchStories = createAsyncThunk('stories/fetchStories', async () => {
  const res = await fetch('http://localhost:3000/story')
  return await res.json()
})

const storiesSlice = createSlice({
  name: 'stories',
  initialState: [],
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchStories.fulfilled, (_, action) => action.payload)
  }
})

export default storiesSlice.reducer

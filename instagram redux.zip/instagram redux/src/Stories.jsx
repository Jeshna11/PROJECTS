import { useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import { fetchStories } from "./redux/storiesSlice"
import { useNavigate } from "react-router-dom"

function Stories() {
  const dispatch = useDispatch()
  const stories = useSelector((state) => state.stories)
  const navigate = useNavigate()

  useEffect(() => {
    dispatch(fetchStories())
  }, [dispatch])

  return (
    <div className="story d-flex">
      {stories.length > 0 ? (
        stories.map((story) => (
          <div key={story.id} className="mx-1" onClick={() => navigate(`/story/${story.id}/${stories.length}`)}>
            <div className="gradient-border">
              <img src={story.profilePic} alt="dp" className="story-dp rounded-circle" />
            </div>
            <p className="text-truncate" style={{ width: "50px" }}>
              {story.username}
            </p>
          </div>
        ))
      ) : (
        <p>Loading</p>
      )}
    </div>
  )
}

export default Stories

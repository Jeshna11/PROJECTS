import { useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import { fetchPosts } from "./redux/postsSlice"

const Posts = () => {
  const dispatch = useDispatch()
  const posts = useSelector((state) => state.posts)

  useEffect(() => {
    dispatch(fetchPosts())
  }, [dispatch])

  return (
    <div className="d-flex">
      {posts.length > 0 ? (
        <div>
          {posts.map((post) => (
            <div className="my-4" key={post.id}>
              <div className="d-flex">
                <img
                  className="dp rounded-circle"
                  src={post.user.profilePic}
                  alt="profilePic"
                />
                <h5>{post.user.username}</h5>
              </div>
              <img className="image" src={post.image} alt="post" />
              <div className="d-flex my-1">
                <i className="bi bi-heart">{post.likes}</i>
                <i className="bi bi-chat"></i>
                <i className="bi bi-send"></i>
              </div>
              <p>{post.caption}</p>
            </div>
          ))}
        </div>
      ) : (
        <div>Loading Posts</div>
      )}
    </div>
  )
}

export default Posts

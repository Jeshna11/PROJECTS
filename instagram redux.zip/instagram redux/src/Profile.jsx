import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux"
import axios from "axios"
import { fetchProfile,updateProfile,setProfileField,} from "./redux/profileSlice"

function Profile() {
  const dispatch = useDispatch()
  const profile = useSelector((state) => state.profile)
  const [followers, setFollowers] = useState([])
  const [unfollowed, setUnfollowed] = useState(0)

  useEffect(() => {
    dispatch(fetchProfile())
    axios
      .get("http://localhost:3000/followers")
      .then((res) => setFollowers(res.data))
      .catch((err) => console.log(err))
  }, [dispatch, unfollowed])

  const handleOnchange = (e) => {
    dispatch(setProfileField({ field: e.target.name, value: e.target.value }))
  }

  const handleUpdate = () => {
    dispatch(updateProfile(profile))
  }

  const handleUnfollow = async (id) => {
    axios
      .delete(`http://localhost:3000/followers/${id}`)
      .then(() => alert("Unfollowed"))
      .then(() => setUnfollowed(!unfollowed))
      .catch((err) => console.log(err))
  }

  return (
    <div className="m-5">
      {profile ? (
        <div>
          <img src={profile.profilePic} className="profile rounded-circle" />
          <h5>{profile.username}</h5>
          <p style={{ fontWeight: "bold", fontSize: "15px" }}>{profile.bio}</p>
          <input
            className="form-control my-4"
            type="text"
            value={profile.username}
            name="username"
            onChange={handleOnchange}
          />
          <input
            className="form-control"
            type="text"
            name="bio"
            value={profile.bio}
            onChange={handleOnchange}
          />
          <button onClick={handleUpdate} className="btn btn-primary my-4">
            Update
          </button>
        </div>
      ) : (
        <div>Loading profile</div>
      )}

      <h4>Followers</h4>
      <br />
      {followers.length > 0 ? (
        followers.map((follower) => (
          <div key={follower.id} className="d-flex my-2">
            <img src={follower.profilePic} className="dp1 rounded-circle" />
            <h5 className="fs-5 mx-2">{follower.username}</h5>
            <button
              onClick={() => handleUnfollow(follower.id)}
              className="btn btn-primary ms-auto"
            >
              unfollow
            </button>
          </div>
        ))
      ) : (
        <div>Loading Profile</div>
      )}
    </div>
  )
}

export default Profile

import { useEffect, useState } from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { fetchProfile } from "./redux/profileSlice";
import { fetchSuggestions } from "./redux/suggestionsSlice";
const Suggestions = () => {
  const dispatch = useDispatch();
  const profile = useSelector((state) => state.profile);
  const suggestions = useSelector((state) => state.suggestions);
  const [followers, setFollowers] = useState([]);
  const [filteredSuggestions, setFilteredSuggestions] = useState([]);
  useEffect(() => {
    if (!profile) dispatch(fetchProfile());
    dispatch(fetchSuggestions());
    axios
      .get("http://localhost:3000/followers")
      .then((res) => setFollowers(res.data))
      .catch((err) => console.error(err));
  }, [dispatch]);
  useEffect(() => {
    const followerIds = new Set(followers.map((f) => f.id));
    const filtered = suggestions.filter((s) => !followerIds.has(s.id));
    setFilteredSuggestions(filtered);
  }, [suggestions, followers]);
  const handleFollow = async (suggestion) => {
    try {
      await axios.post("http://localhost:3000/followers", {
        id: suggestion.id,
        username: suggestion.username,
        profilePic: suggestion.profilePic,
      });
      alert("Followed");
      setFilteredSuggestions((prev) =>
        prev.filter((s) => s.id !== suggestion.id)
      );
      setFollowers((prev) => [...prev, suggestion]);
    } catch (err) {
      console.error("Follow error:", err);
    }
  };
  return (
    <div className="suggestions m-4">
      {profile ? (
        <div className="d-flex">
          <img
            className="me rounded-circle"
            src={profile.profilePic}
            alt="profilePic"
          />
          <h5 className="mx-2">{profile.username}</h5>
          <a className="ms-auto">Switch</a>
        </div>
      ) : (
        <p>Loading profile...</p>
      )}
      <br />
      <div className="d-flex mt-2">
        <p style={{ fontWeight: "bold" }}>Suggested for You</p>
        <b className="ms-auto">See All</b>
      </div>
      {filteredSuggestions.length > 0 ? (
        filteredSuggestions.map((suggestion) => (
          <div key={suggestion.id} className="d-flex unfollow">
            <img
              className="suggest rounded-circle"
              src={suggestion.profilePic}
              alt="profilePic"
            />
            <h5 className="mx-2">{suggestion.username}</h5>
            <button
              onClick={() => handleFollow(suggestion)}
              className="cursor-pointer btn btn-primary ms-auto mb-2"
            >
              Follow
            </button>
          </div>
        ))
      ) : (
        <div>No more suggestions</div>
      )}
    </div>
  );
};
export default Suggestions;